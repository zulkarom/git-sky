<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '9U7Xgkvaf2JCkZNA-MbUXTT4ZAxevUqR',
        ],
		/* 'workflowSource' => [
          'class' => '\raoul2000\workflow\source\php\WorkflowPhpSource',
          'namespace' => ' \common\modules\ReqeustWorkflow' 
        ] */
		
		
		   
		'formatter' => [
			'class' => 'yii\i18n\Formatter',
			'dateFormat' => 'php:d M Y',
			'decimalSeparator' => '.',
			'thousandSeparator' => ', ',
			'currencyCode' => 'RM',
			'nullDisplay' => '',          
			],
		
		
    ],
];

if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];
}

return $config;
